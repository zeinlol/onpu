T_CARD = 'CreditCard'
T_CLIENT = 'Client'
T_ADMIN = 'Administrator'
T_QUESTIONS = 'Questions'
