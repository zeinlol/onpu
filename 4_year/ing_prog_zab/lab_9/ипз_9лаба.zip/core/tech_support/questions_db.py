from core.utils.typing import T_QUESTIONS

users_questions: list[T_QUESTIONS] = []
