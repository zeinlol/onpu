from core.tech_support.ask_question import ask_question
