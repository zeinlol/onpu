from core.utils.typing import T_CLIENT


def show_user_questions(client: T_CLIENT):
    client.print_questions()
